package com.tuma.screentranslate

import android.app.*
import android.content.*
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.translate.Translation
import android.speech.tts.TextToSpeech
import java.util.*

class CaptureService : Service(), TextToSpeech.OnInitListener {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var bubble: View? = null
    private var wm: WindowManager? = null
    private var tts: TextToSpeech? = null
    private var busy = false

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY

        startForeground(10, notification())
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)

        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels,
            PixelFormat.RGBA_8888, 2)

        virtualDisplay = projection!!.createVirtualDisplay(
            "ScreenTranslate", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )
        showBubble()
        return START_STICKY
    }

    private fun showBubble() {
        if (!Settings.canDrawOverlays(this)) return
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val b = TextView(this).apply {
            text = "文→"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(25, 118, 210))
            setPadding(18, 12, 18, 12)
            setOnClickListener { captureAndTranslate() }
        }
        bubble = b

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.END
        p.x = 20
        p.y = 250
        wm!!.addView(b, p)
    }

    private fun captureAndTranslate() {
        if (busy) return
        busy = true
        reader?.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * image.width
                val bitmap = Bitmap.createBitmap(
                    image.width + rowPadding / pixelStride,
                    image.height, Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)
                image.close()
                runOcr(bitmap)
            } catch (e: Exception) {
                image.close()
                busy = false
            }
        }, Handler(Looper.getMainLooper()))
    }

    private fun runOcr(bitmap: Bitmap) {
        val input = InputImage.fromBitmap(bitmap, 0)
        val recognizer = TextRecognition.getClient(
            ChineseTextRecognizerOptions.Builder().build()
        )
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val text = result.text.trim()
                if (text.isEmpty()) {
                    showResult("Không nhận diện được chữ.")
                    busy = false
                    return@addOnSuccessListener
                }
                translate(text)
            }
            .addOnFailureListener {
                showResult("OCR lỗi: ${it.message}")
                busy = false
            }
    }

    private fun translate(source: String) {
        val options = TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.CHINESE)
            .setTargetLanguage(TranslateLanguage.VIETNAMESE)
            .build()
        val translator = Translation.getClient(options)
        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(source)
                    .addOnSuccessListener {
                        showResult(it)
                        speak(it)
                        translator.close()
                        busy = false
                    }
                    .addOnFailureListener {
                        showResult("Dịch lỗi: ${it.message}")
                        translator.close()
                        busy = false
                    }
            }
            .addOnFailureListener {
                showResult("Không tải được model dịch. Hãy bật mạng.")
                translator.close()
                busy = false
            }
    }

    private fun showResult(text: String) {
        Handler(Looper.getMainLooper()).post {
            val box = TextView(this).apply {
                this.text = text
                textSize = 18f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.argb(235, 20, 20, 20))
                setPadding(28, 20, 28, 20)
            }
            val type = if (Build.VERSION.SDK_INT >= 26)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )
            p.gravity = Gravity.BOTTOM
            p.y = 100
            wm?.addView(box, p)
            box.postDelayed({ try { wm?.removeView(box) } catch (_: Exception) {} }, 6000)
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "screen_translate")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel("translate", "Screen Translate",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    private fun notification(): Notification {
        return Notification.Builder(this, "translate")
            .setContentTitle("Screen Translate")
            .setContentText("Bóng dịch đang hoạt động")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("vi", "VN")
        }
    }

    override fun onDestroy() {
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
        virtualDisplay?.release()
        projection?.stop()
        reader?.close()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
